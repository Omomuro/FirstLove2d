-- Class code 

Player = {
	health = 100,
	gold = 0,
	exp = 0, 
	name = ""
} 

Player.__index = Player

-- Player construct 
function Player.new(self, name)
	-- body
	local self = setmetatable({}, Player)
	self.name = name 
	return self 
end



-- Player set_helpers 

function Player.setHealth(self, health)
	-- body
	self.health = health
end

function Player.setGold(self, gold)
	-- body
	self.gold = gold 
end

function Player.setExp(self, exp)
	-- body
	self.exp = exp 
end

function Player.setName(self, name)
	-- body
	self.name = name
end



-- Player get_helpers

function Player.getHealth(self)
	-- body
	return self.health
end

function Player.getGold(self)
	-- body
	return self.gold
end

function Player.getExp(self)
	-- body
	return self.exp
end

function Player.getName(self)
	-- body
	return self.name
end



-- ShopItem Class 

ShopItem = {
	
}

ShopItem.__index = ShopItem



-- Button Class 
Button = {
	x = 0,
	y = 0,
	height = 0,
	width = 0,
	clicked = false 
}

Button.__index = Button

-- Button Construct 
function Button.new(self, x, y, height, width)
	-- body
	local self = setmetatable({}, Button)
	self.x = x 
	self.y = y 
	self.height = height 
	self.width = width
	return self 
end

-- Button set_helpers 
function Button.setX(self, x)
	-- body
	self.x = x 
end

function Button.setY(self, y)
	-- body
	self.y = y
end

function Button.setHeight(self, height)
	-- body
	self.height = height
end

function Button.setWidth(self, width)
	-- body
	self.width = width 
end

function Button.setClickTrue(self)
	-- body
	self.clicked = true
end

function Button.setClickFalse(self)
	-- body
	self.clicked = false 
end

-- Button get_helpers 
function Button.getX(self)
	-- body
	return self.x 
end

function Button.getY(self)
	-- body
	return self.y
end

function Button.getHeight(self)
	-- body
	return self.height
end

function Button.getWidth(self)
	-- body
	return self.width
end

function Button.getClick(self)
	-- body
	return self.clicked
end


-- Button functions 

function Button.draw(self, type)
	-- body
	love.graphics.rectangle("line", self.x, self.y, self.width, self.height)
end

function Button.isClick(self, mx, my, isDown)
	-- body
	if isDown == true and mx > self.x and mx < self.x + self.width and my > self.y and my < self.y + self.height then 
		love.graphics.print("DOWN", 100,300)
		local gold = p:getGold()
		p:setGold(gold + 1)
	end 
end



-- Game code 

function love.load(arg)
	p = Player:new("TEST NAME: BOB")
	wx, wy = love.graphics.getDimensions() 
	playerZone = Button:new(wx*0.5, wy*0.10, wy*0.7, wx*0.47)
end

a = 0

function love.update(dt)
	a = a + dt 
end

function love.draw()
	love.graphics.print(wy * 0.20, 200, 200)
	love.graphics.print(love.mouse.getX(), 10, 50)
	love.graphics.print(love.mouse.getY(), 50, 50)
	love.graphics.print(p:getName(), 10,10)
	love.graphics.print(p:getExp(), 10,20)
	love.graphics.print(p:getGold(), 10,30)
	love.graphics.print(p:getHealth(), 10,40)
	love.graphics.rectangle("line", 100, 100,100,100)
	love.graphics.print(playerZone:getX(), 300, 300)
	playerZone:draw("line")
	playerZone:isClick(love.mouse.getX(), love.mouse.getY(), love.mouse.isDown(1))
	love.graphics.print(a, 210,100)
end
